import { Link, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { Menu, X, LayoutDashboard, Map, Search } from "lucide-react";

export function Header() {
  const location = useLocation();
  const [open, setOpen]       = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [tick, setTick]       = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTick(n => n + 1), 1000);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const now     = new Date();
  const timeStr = now.toLocaleTimeString("en-IN", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = now.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  const path    = location.pathname;

  const NAV = [
    { to: "/",          label: "OVERVIEW",  icon: <LayoutDashboard className="h-3 w-3" /> },
    { to: "/search",    label: "SEARCH",    icon: <Search className="h-3 w-3" /> },
    { to: "/dashboard", label: "DASHBOARD", icon: <Map className="h-3 w-3" /> },
  ];

  return (
    <header className="sticky top-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(14,18,26,0.95)" : "rgba(14,18,26,0.85)",
        backdropFilter: "blur(16px)",
        borderBottom: "1px solid hsl(216 18% 14%)",
        boxShadow: scrolled ? "0 4px 24px rgba(0,0,0,0.4)" : "none",
      }}>
      <div className="h-px w-full" style={{ background: "linear-gradient(90deg, transparent, hsl(152 80% 48% / 0.4), hsl(43 95% 52% / 0.3), transparent)" }} />

      <div className="container flex h-14 items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-3 group flex-shrink-0">
          <div className="relative flex h-8 w-8 items-center justify-center rounded overflow-hidden"
            style={{ background: "hsl(216 24% 12%)", border: "1px solid hsl(152 80% 48% / 0.3)" }}>
            <span className="font-command text-sm" style={{ color: "hsl(152 80% 55%)" }}>N</span>
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-command text-base tracking-widest" style={{ color: "hsl(152 80% 55%)" }}>NBIG</span>
              <span className="label-caps hidden sm:inline" style={{ color: "hsl(216 12% 35%)" }}>v2.0</span>
            </div>
            <div className="label-caps hidden md:block" style={{ color: "hsl(216 12% 30%)", letterSpacing: "0.14em" }}>
              NATIONAL MOBILITY INTELLIGENCE
            </div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {NAV.map(({ to, label, icon }) => {
            const active = path === to || (to !== "/" && path.startsWith(to));
            return (
              <Link key={to} to={to}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded font-mono text-xs transition-all duration-150"
                style={{
                  color: active ? "hsl(152 80% 55%)" : "hsl(216 12% 45%)",
                  background: active ? "hsl(152 80% 48% / 0.08)" : "transparent",
                  borderBottom: active ? "1px solid hsl(152 80% 48% / 0.4)" : "1px solid transparent",
                  letterSpacing: "0.1em",
                }}>
                {icon}{label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden md:flex items-center gap-4 flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="radar-ping" />
            <span className="font-mono text-xs" style={{ color: "hsl(152 80% 48%)" }}>LIVE</span>
          </div>
          <div className="font-mono text-right" style={{ color: "hsl(216 12% 40%)" }}>
            <div className="text-xs font-medium" style={{ color: "hsl(152 80% 45%)", fontSize: 11, letterSpacing: "0.08em" }}>{timeStr}</div>
            <div style={{ fontSize: 9, letterSpacing: "0.06em" }}>{dateStr}</div>
          </div>
          <Link to="/dashboard" className="btn-command flex items-center gap-1.5 px-4 py-1.5" style={{ fontSize: 11, letterSpacing: "0.1em" }}>
            DASHBOARD
          </Link>
        </div>

        <button onClick={() => setOpen(!open)} className="lg:hidden p-2 rounded" style={{ color: "hsl(216 12% 50%)" }}>
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden border-t animate-fade-in" style={{ background: "hsl(216 28% 7%)", borderColor: "hsl(216 18% 14%)" }}>
          <div className="container py-3 flex flex-col gap-1">
            {NAV.map(({ to, label }) => (
              <Link key={to} to={to} onClick={() => setOpen(false)}
                className="px-3 py-2.5 rounded font-mono text-sm transition-colors"
                style={{ color: path === to ? "hsl(152 80% 55%)" : "hsl(216 12% 55%)" }}>
                {label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
