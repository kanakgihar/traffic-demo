import { Bus } from "@/data/buses";
import { Link } from "react-router-dom";
import { Clock, Users, ArrowRight, Gauge, Zap, AlertTriangle } from "lucide-react";
import { predictSeatFill } from "@/services/aiPrediction";

export function BusCard({ bus }: { bus: Bus }) {
  const occ = Math.round(((bus.totalSeats - bus.availableSeats) / bus.totalSeats) * 100);
  const { minsUntilFull, confidence } = predictSeatFill(bus);
  const statusColor = bus.status === "on-time" ? "hsl(152 80% 55%)" : bus.status === "delayed" ? "hsl(4 84% 68%)" : "hsl(43 95% 62%)";
  const statusChip  = bus.status === "on-time" ? "chip-on-time" : bus.status === "delayed" ? "chip-delayed" : "chip-filling";
  const barColor    = occ >= 90 ? "hsl(4 84% 55%)" : occ >= 70 ? "hsl(43 95% 52%)" : "hsl(152 80% 48%)";
  const riskColor   = bus.overcrowdingRisk >= 90 ? "hsl(4 84% 68%)" : bus.overcrowdingRisk >= 70 ? "hsl(43 95% 62%)" : "hsl(152 80% 55%)";

  return (
    <Link to={`/track/${bus.id}`} className="panel rounded-lg block p-4 group" style={{ textDecoration: "none" }}>
      {/* Header */}
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5 mb-1.5">
            <span className="font-mono text-xs font-semibold rounded px-2 py-0.5" style={{ background: "hsl(152 80% 48% / 0.1)", color: "hsl(152 80% 55%)", border: "1px solid hsl(152 80% 48% / 0.2)" }}>
              {bus.busNumber}
            </span>
            <span className={`label-caps px-2 py-0.5 rounded ${statusChip}`}>{bus.status.replace("-"," ").toUpperCase()}</span>
            {bus.isDeviated && <span className="label-caps chip-critical rounded px-1.5 py-0.5">DEVIATION</span>}
          </div>
          <div className="flex items-center gap-1 font-command text-sm font-bold" style={{ color: "hsl(160 10% 80%)", letterSpacing: "0.04em" }}>
            {bus.source}
            <ArrowRight className="h-3 w-3 flex-shrink-0 text-dim transition-transform group-hover:translate-x-0.5" />
            {bus.destination}
          </div>
          <div className="font-mono text-dim mt-0.5" style={{ fontSize: 10 }}>{bus.route.length} STOPS · {bus.distanceKm} KM</div>
        </div>
        <div className="text-right flex-shrink-0">
          <div className="font-command text-xl font-bold" style={{ color: "hsl(160 10% 88%)" }}>₹{bus.fare}</div>
          <div className="label-caps text-dim">PER SEAT</div>
        </div>
      </div>

      {/* Stats */}
      <div className="flex flex-wrap gap-4 mb-3 font-mono text-xs text-dim">
        <span className="flex items-center gap-1"><Clock className="h-3 w-3" /><strong style={{ color: "hsl(160 10% 80%)" }}>{bus.etaMinutes}m</strong></span>
        <span className="flex items-center gap-1"><Users className="h-3 w-3" /><strong className={bus.availableSeats < 5 ? "text-critical" : ""} style={bus.availableSeats >= 5 ? { color: "hsl(160 10% 80%)" } : {}}>{bus.availableSeats}/{bus.totalSeats}</strong></span>
        <span className="flex items-center gap-1"><Gauge className="h-3 w-3" /><strong style={{ color: "hsl(160 10% 80%)" }}>{bus.speed} km/h</strong></span>
        <span className="ml-auto">{bus.departsAt}</span>
      </div>

      {/* Occupancy bar */}
      <div className="progress-track mb-1">
        <div className="progress-bar" style={{ width: `${occ}%`, background: barColor }} />
      </div>
      <div className="flex justify-between font-mono text-dim mb-3" style={{ fontSize: 10 }}>
        <span>{occ}% OCCUPIED</span>
        <span>RISK SCORE <strong style={{ color: riskColor }}>{bus.overcrowdingRisk}</strong></span>
      </div>

      {/* AI prediction */}
      {minsUntilFull !== null && (
        <div className="flex items-center gap-2 rounded px-2.5 py-2" style={{ background: "hsl(43 95% 52% / 0.06)", border: "1px solid hsl(43 95% 52% / 0.15)" }}>
          <Zap className="h-3 w-3 flex-shrink-0 text-amber" />
          <span className="label-caps text-amber">AI</span>
          <span className="font-mono text-xs text-dim">
            FULL IN ~<strong style={{ color: confidence === "high" ? "hsl(152 80% 55%)" : confidence === "medium" ? "hsl(43 95% 62%)" : "hsl(216 12% 45%)" }}>{minsUntilFull}m</strong>
            <span className="ml-1" style={{ fontSize: 10 }}>({confidence.toUpperCase()})</span>
          </span>
        </div>
      )}
    </Link>
  );
}
