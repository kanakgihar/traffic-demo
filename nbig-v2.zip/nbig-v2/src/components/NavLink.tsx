/**
 * NavLink.tsx
 * Re-exported for backward compatibility. Use Header.tsx nav links for new code.
 */
export { } from "react-router-dom";
