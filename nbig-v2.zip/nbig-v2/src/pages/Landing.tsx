/**
 * Landing.tsx — NBIG v2
 * Cleaned: removed fake ticker stats, trimmed roadmap to credible phases only.
 */
import { Link } from "react-router-dom";
import { Header } from "@/components/Header";
import { ArrowRight, Shield, Zap, Globe, BarChart3, Radio, CheckCircle } from "lucide-react";

const STATS = [
  { v: "1.2B+", l: "BUS JOURNEYS/YEAR", sub: "served by India's national network" },
  { v: "5,000+", l: "OPERATORS", sub: "no unified digital intelligence layer" },
  { v: "₹4,200Cr", l: "ANNUAL REVENUE", sub: "limited real-time accountability" },
  { v: "8.4M T", l: "CO₂/YEAR", sub: "reducible with modal shift + optimisation" },
];

const CAPABILITIES = [
  { icon: "⬡", label: "LIVE GPS SIMULATION", body: "Sub-5s position updates with route corridor deviation detection across all active buses.", color: "radar" },
  { icon: "⬡", label: "AI SEAT PREDICTION", body: "Rate-extrapolation over rolling occupancy history predicts seat fill time with confidence scoring.", color: "amber" },
  { icon: "⬡", label: "RULE-BASED OPTIMIZER", body: "Documented threshold engine generates frequency, reroute, and reserve recommendations per corridor.", color: "radar" },
  { icon: "⬡", label: "CASCADE RISK DETECTION", body: "When a delayed bus reaches a hub, downstream connecting services are automatically flagged.", color: "amber" },
  { icon: "⬡", label: "DELAY PUSH ALERTS", body: "Passengers receive real-time delay notifications with updated ETAs as status changes.", color: "radar" },
  { icon: "⬡", label: "5-MINUTE REPLAY", body: "Digital twin replay buffer stores the last 60 ticks — scrub back to diagnose any fleet event.", color: "amber" },
];

const ROADMAP = [
  {
    ph: "01", label: "PROTOTYPE", status: "live",
    title: "Simulated Intelligence Platform",
    items: ["Full rule-based optimizer", "AI seat prediction engine", "Combined authority dashboard", "Cascade risk detection", "Replay buffer (digital twin lite)"]
  },
  {
    ph: "02", label: "PILOT", status: "next",
    title: "2-City Live Integration",
    items: ["GTFS-RT feed integration", "Real GPS hardware (OBD-II)", "Driver mobile app", "Passenger PWA", "STC partnership (UPSRTC / BMTC)"]
  },
  {
    ph: "03", label: "SCALE", status: "future",
    title: "National Rollout",
    items: ["20+ state STC integrations", "ML demand forecasting (XGBoost)", "Dynamic pricing engine", "MoRTH API compatibility", "Open developer API"]
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <Header />

      {/* Hero */}
      <section className="relative min-h-[88vh] flex items-center bg-command-hero overflow-hidden">
        <div className="bg-command-grid absolute inset-0 pointer-events-none" />
        <div className="container relative z-10 py-20">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded" style={{ background: "hsl(152 80% 48% / 0.08)", border: "1px solid hsl(152 80% 48% / 0.25)" }}>
                <span className="radar-ping" />
                <span className="font-mono text-xs" style={{ color: "hsl(152 80% 55%)", letterSpacing: "0.12em" }}>PROTOTYPE · LIVE DEMO</span>
              </div>
            </div>

            <h1 className="font-command mb-4" style={{ fontSize: "clamp(32px,5vw,56px)", color: "hsl(160 10% 90%)", lineHeight: 1.1, letterSpacing: "0.02em" }}>
              NATIONAL BUS<br />
              <span style={{ color: "hsl(152 80% 55%)" }}>INTELLIGENCE GRID</span>
            </h1>

            <p className="font-mono text-sm mb-8" style={{ color: "hsl(216 12% 50%)", maxWidth: 520, lineHeight: 1.7 }}>
              A data-driven prototype for real-time fleet management, delay prediction, and route optimisation across India's intercity bus network.
            </p>

            <div className="flex flex-wrap gap-3">
              <Link to="/search" className="btn-command flex items-center gap-2 px-6 py-3 rounded-lg font-command text-sm" style={{ letterSpacing: "0.1em" }}>
                SEARCH BUSES <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/dashboard" className="flex items-center gap-2 px-6 py-3 rounded-lg font-command text-sm"
                style={{ border: "1px solid hsl(216 18% 22%)", color: "hsl(216 12% 55%)", letterSpacing: "0.1em" }}>
                AUTHORITY DASHBOARD
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 border-y" style={{ borderColor: "hsl(216 18% 12%)" }}>
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {STATS.map(s => (
              <div key={s.l} className="text-center">
                <div className="font-command text-3xl mb-1" style={{ color: "hsl(152 80% 55%)" }}>{s.v}</div>
                <div className="label-caps mb-1" style={{ fontSize: 9, color: "hsl(216 12% 40%)" }}>{s.l}</div>
                <div className="font-mono text-xs text-dim">{s.sub}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Capabilities */}
      <section className="py-20">
        <div className="container">
          <div className="mb-10">
            <div className="label-caps text-dim mb-2" style={{ fontSize: 10 }}>PLATFORM CAPABILITIES</div>
            <h2 className="font-command text-2xl" style={{ color: "hsl(160 10% 85%)" }}>What the system does</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {CAPABILITIES.map(c => (
              <div key={c.label} className="panel rounded-lg p-5">
                <div className="text-xl mb-3" style={{ color: c.color === "radar" ? "hsl(152 80% 55%)" : "hsl(43 95% 62%)" }}>{c.icon}</div>
                <div className="label-caps mb-2" style={{ fontSize: 10, color: "hsl(216 12% 50%)" }}>{c.label}</div>
                <p className="font-mono text-xs text-dim leading-relaxed">{c.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Roadmap */}
      <section className="py-20 border-t" style={{ borderColor: "hsl(216 18% 12%)" }}>
        <div className="container">
          <div className="mb-10">
            <div className="label-caps text-dim mb-2" style={{ fontSize: 10 }}>DEVELOPMENT ROADMAP</div>
            <h2 className="font-command text-2xl" style={{ color: "hsl(160 10% 85%)" }}>Path to production</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {ROADMAP.map(ph => {
              const isLive = ph.status === "live";
              const isNext = ph.status === "next";
              return (
                <div key={ph.ph} className="panel rounded-lg p-5" style={{ border: isLive ? "1px solid hsl(152 80% 48% / 0.35)" : undefined }}>
                  <div className="flex items-center gap-3 mb-3">
                    <span className="font-command text-xs" style={{ color: "hsl(216 12% 35%)" }}>PHASE {ph.ph}</span>
                    <span className="label-caps px-2 py-0.5 rounded" style={{
                      fontSize: 9,
                      background: isLive ? "hsl(152 80% 48% / 0.12)" : "transparent",
                      color: isLive ? "hsl(152 80% 55%)" : isNext ? "hsl(43 95% 62%)" : "hsl(216 12% 40%)",
                      border: `1px solid ${isLive ? "hsl(152 80% 48% / 0.3)" : isNext ? "hsl(43 95% 52% / 0.3)" : "hsl(216 18% 18%)"}`,
                    }}>
                      {ph.label} {isLive ? "✓" : ""}
                    </span>
                  </div>
                  <div className="font-command text-sm mb-3" style={{ color: "hsl(160 10% 75%)" }}>{ph.title}</div>
                  <ul className="space-y-1.5">
                    {ph.items.map(item => (
                      <li key={item} className="flex items-start gap-2 font-mono text-xs text-dim">
                        <CheckCircle className="h-3 w-3 mt-0.5 flex-shrink-0" style={{ color: isLive ? "hsl(152 80% 48%)" : "hsl(216 18% 22%)" }} />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-t" style={{ borderColor: "hsl(216 18% 12%)" }}>
        <div className="container text-center">
          <h2 className="font-command text-2xl mb-4" style={{ color: "hsl(160 10% 85%)" }}>Explore the prototype</h2>
          <p className="font-mono text-xs text-dim mb-8 max-w-md mx-auto">All data is simulated. The intelligence engine, predictions, and optimization recommendations run entirely client-side.</p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link to="/search" className="btn-command px-8 py-3 rounded-lg font-command text-sm" style={{ letterSpacing: "0.1em" }}>
              PASSENGER VIEW
            </Link>
            <Link to="/dashboard" className="px-8 py-3 rounded-lg font-command text-sm"
              style={{ border: "1px solid hsl(216 18% 22%)", color: "hsl(216 12% 55%)", letterSpacing: "0.1em" }}>
              AUTHORITY VIEW
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
