/**
 * TrackBus.tsx — NBIG v2 Individual Bus Tracking (Passenger View)
 * Simplified: removed engineTempScore / fuelLevelPct for passengers.
 * Added: delay push notification toast on status change.
 * Focus: route progress, ETA countdown, seat availability, AI prediction, booking.
 */
import { useParams, useNavigate, Link } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import { useBusSimulation } from "@/hooks/useBusSimulation";
import { predictSeatFill } from "@/services/aiPrediction";
import { Header } from "@/components/Header";
import { fmtCountdown, generateBookingId } from "@/utils/formatters";
import {
  ArrowLeft, Clock, Users, CheckCircle2, Zap, Bell
} from "lucide-react";

export default function TrackBus() {
  const { id }     = useParams<{ id: string }>();
  const navigate   = useNavigate();
  const { getBus } = useBusSimulation();
  const bus        = getBus(id ?? "");

  const [booked, setBooked]   = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [notification, setNotification] = useState<string | null>(null);
  const prevStatus = useRef<string | undefined>(undefined);
  const prevEta    = useRef<number | undefined>(undefined);
  const bookingId  = useRef(generateBookingId());

  useEffect(() => { if (bus) setCountdown(bus.etaMinutes * 60); }, [bus?.id]);

  // Countdown timer
  useEffect(() => {
    const t = setInterval(() => setCountdown(c => Math.max(0, c - 1)), 1000);
    return () => clearInterval(t);
  }, []);

  // Push notification on delay status change
  useEffect(() => {
    if (!bus) return;
    if (prevStatus.current && prevStatus.current !== bus.status && bus.status === "delayed") {
      const delay = bus.etaMinutes - (bus.scheduledEta ?? bus.etaMinutes);
      const newEtaStr = new Date(Date.now() + bus.etaMinutes * 60000)
        .toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true });
      setNotification(
        `${bus.busNumber} is now running ${delay > 0 ? `+${delay}m` : "behind schedule"}. Updated ETA: ${newEtaStr}`
      );
      setTimeout(() => setNotification(null), 8000);
    }
    prevStatus.current = bus.status;
    prevEta.current    = bus.etaMinutes;
  }, [bus?.status, bus?.etaMinutes]);

  if (!bus) return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="panel rounded-lg p-10 text-center max-w-sm">
          <div className="font-command text-4xl text-dim mb-4">404</div>
          <p className="font-command text-lg mb-2" style={{ color: "hsl(160 10% 70%)", letterSpacing: "0.04em" }}>UNIT NOT FOUND</p>
          <p className="font-mono text-xs text-dim mb-6">This unit may have completed its route.</p>
          <button onClick={() => navigate("/search")} className="btn-command px-6 py-2.5 rounded w-full">
            BACK TO SEARCH
          </button>
        </div>
      </div>
    </div>
  );

  const totalSecs   = bus.etaMinutes * 60;
  const progress    = Math.max(5, Math.min(95, ((totalSecs - countdown) / Math.max(1, totalSecs)) * 100));
  const occupancy   = Math.round(((bus.totalSeats - bus.availableSeats) / bus.totalSeats) * 100);
  const schedSlip   = bus.etaMinutes - bus.scheduledEta;
  const { minsUntilFull, confidence } = predictSeatFill(bus);

  const statusColor  = bus.status === "on-time" ? "hsl(152 80% 55%)" : bus.status === "delayed" ? "hsl(4 84% 68%)" : "hsl(43 95% 62%)";
  const statusLabel  = bus.status === "on-time" ? "ON-TIME" : bus.status === "delayed" ? "DELAYED" : "FILLING FAST";
  const barColor     = occupancy >= 90 ? "hsl(4 84% 55%)" : occupancy >= 70 ? "hsl(43 95% 52%)" : "hsl(152 80% 48%)";
  const confColor    = confidence === "high" ? "hsl(152 80% 55%)" : confidence === "medium" ? "hsl(43 95% 62%)" : "hsl(216 12% 45%)";

  if (booked) return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="max-w-md w-full text-center animate-scale-in">
          <div className="relative mx-auto mb-6 w-20 h-20">
            <div className="w-20 h-20 rounded-full flex items-center justify-center"
              style={{ background: "hsl(152 80% 48% / 0.1)", border: "1px solid hsl(152 80% 48% / 0.3)" }}>
              <CheckCircle2 className="h-10 w-10 text-radar" />
            </div>
          </div>
          <div className="label-caps text-radar mb-2 tracking-widest">BOOKING CONFIRMED</div>
          <h1 className="font-command text-3xl mb-1" style={{ color: "hsl(160 10% 88%)", letterSpacing: "0.04em" }}>SEAT RESERVED</h1>
          <p className="font-mono text-xs text-dim mb-6">{bus.busNumber} · {bus.source} → {bus.destination}</p>
          <div className="panel rounded-lg p-5 text-left mb-6">
            <div className="grid grid-cols-2 gap-4">
              {[
                ["BUS", bus.busNumber], ["ROUTE", `${bus.source}→${bus.destination}`],
                ["DEPARTURE", bus.departsAt], ["FARE", `₹${bus.fare}`],
                ["BOOKING ID", bookingId.current], ["STATUS", "CONFIRMED"],
              ].map(([k, v]) => (
                <div key={k}>
                  <div className="label-caps text-dim mb-1">{k}</div>
                  <div className="font-mono text-xs font-semibold" style={{
                    color: k === "STATUS" ? "hsl(152 80% 55%)" : "hsl(160 10% 75%)", fontSize: k === "BOOKING ID" ? 10 : 12
                  }}>{v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Simulated push notification explanation */}
          <div className="panel rounded-lg p-4 text-left mb-6" style={{ border: "1px solid hsl(43 95% 52% / 0.3)" }}>
            <div className="flex items-center gap-2 mb-2">
              <Bell className="h-4 w-4" style={{ color: "hsl(43 95% 62%)" }} />
              <span className="label-caps" style={{ fontSize: 9, color: "hsl(43 95% 62%)" }}>DELAY ALERTS ACTIVE</span>
            </div>
            <p className="font-mono text-xs text-dim">You will receive a notification if {bus.busNumber} is delayed. Alerts appear in real-time as status changes.</p>
          </div>

          <Link to="/search" className="btn-command px-6 py-2.5 rounded inline-block" style={{ letterSpacing: "0.08em" }}>
            BACK TO SEARCH
          </Link>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Push notification toast */}
      {notification && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-scale-in"
          style={{ maxWidth: 420, width: "90%" }}>
          <div className="rounded-lg p-4 shadow-lg" style={{ background: "hsl(216 24% 12%)", border: "1px solid hsl(4 84% 68% / 0.4)" }}>
            <div className="flex items-start gap-3">
              <Bell className="h-4 w-4 mt-0.5 flex-shrink-0" style={{ color: "hsl(4 84% 68%)" }} />
              <div>
                <div className="label-caps mb-1" style={{ fontSize: 9, color: "hsl(4 84% 68%)" }}>DELAY ALERT — {bus.busNumber}</div>
                <p className="font-mono text-xs" style={{ color: "hsl(160 10% 75%)" }}>{notification}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="container py-8 max-w-2xl animate-fade-in">
        {/* Back */}
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 mb-6 font-mono text-xs text-dim hover:text-radar transition-colors">
          <ArrowLeft className="h-4 w-4" /> BACK
        </button>

        {/* Bus header */}
        <div className="panel rounded-lg p-5 mb-4">
          <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <div className="font-command text-xl" style={{ color: "hsl(152 80% 55%)" }}>{bus.busNumber}</div>
                <div className="label-caps px-2 py-0.5 rounded" style={{ fontSize: 9, color: statusColor, border: `1px solid ${statusColor}44` }}>
                  {statusLabel}
                </div>
              </div>
              <div className="font-mono text-xs text-dim">{bus.source} → {bus.destination}</div>
              <div className="font-mono text-xs text-dim mt-1">Driver: {bus.driver}</div>
            </div>
            <div className="text-right">
              <div className="label-caps text-dim mb-1" style={{ fontSize: 9 }}>ETA</div>
              <div className="font-command text-3xl" style={{ color: "hsl(152 80% 55%)" }}>
                {fmtCountdown(countdown)}
              </div>
              {schedSlip !== 0 && (
                <div className="font-mono text-xs mt-1" style={{ color: schedSlip > 0 ? "hsl(4 84% 68%)" : "hsl(152 80% 55%)" }}>
                  {schedSlip > 0 ? `+${schedSlip}m vs schedule` : `${Math.abs(schedSlip)}m ahead`}
                </div>
              )}
            </div>
          </div>

          {/* Route progress */}
          <div className="mb-2">
            <div className="flex justify-between font-mono text-xs text-dim mb-1">
              <span>{bus.source}</span>
              <span>{bus.destination}</span>
            </div>
            <div className="h-2 rounded-full" style={{ background: "hsl(216 18% 14%)" }}>
              <div className="h-2 rounded-full transition-all duration-700" style={{ width: `${bus.progressPct}%`, background: statusColor }} />
            </div>
            <div className="flex justify-between font-mono mt-1" style={{ fontSize: 9, color: "hsl(216 12% 35%)" }}>
              <span>DEPARTED</span>
              <span>{Math.round(bus.progressPct)}% COMPLETE</span>
              <span>ARRIVING</span>
            </div>
          </div>
        </div>

        {/* Route stops */}
        <div className="panel rounded-lg p-5 mb-4">
          <div className="label-caps text-dim mb-3" style={{ fontSize: 9 }}>ROUTE STOPS</div>
          <div className="flex flex-wrap gap-2">
            {bus.route.map((stop, i) => {
              const isSource = stop === bus.source;
              const isDest   = stop === bus.destination;
              const isPassed = bus.progressPct > (i / (bus.route.length - 1)) * 100;
              return (
                <div key={stop} className="flex items-center gap-1.5">
                  <span className="font-mono text-xs rounded px-2 py-1"
                    style={{
                      background: isSource || isDest ? "hsl(152 80% 48% / 0.12)" : isPassed ? "hsl(216 24% 14%)" : "hsl(216 24% 10%)",
                      color: isSource || isDest ? "hsl(152 80% 55%)" : isPassed ? "hsl(216 12% 55%)" : "hsl(216 12% 35%)",
                      border: `1px solid ${isSource || isDest ? "hsl(152 80% 48% / 0.3)" : "hsl(216 18% 18%)"}`,
                    }}>
                    {stop}
                  </span>
                  {i < bus.route.length - 1 && <span className="text-dim" style={{ fontSize: 10 }}>›</span>}
                </div>
              );
            })}
          </div>
        </div>

        {/* Seat availability + AI prediction */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="panel rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Users className="h-3.5 w-3.5 text-dim" />
              <span className="label-caps text-dim" style={{ fontSize: 9 }}>SEAT AVAILABILITY</span>
            </div>
            <div className="font-command text-2xl mb-1" style={{ color: barColor }}>
              {bus.availableSeats} <span className="font-mono text-sm text-dim">/ {bus.totalSeats}</span>
            </div>
            <div className="h-1.5 rounded-full mb-1" style={{ background: "hsl(216 18% 14%)" }}>
              <div className="h-1.5 rounded-full transition-all duration-700" style={{ width: `${occupancy}%`, background: barColor }} />
            </div>
            <div className="font-mono text-xs text-dim">{occupancy}% occupied</div>
          </div>

          <div className="panel rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="h-3.5 w-3.5 text-dim" />
              <span className="label-caps text-dim" style={{ fontSize: 9 }}>AI SEAT PREDICTION</span>
            </div>
            {minsUntilFull !== null ? (
              <>
                <div className="font-command text-2xl mb-1" style={{ color: "hsl(43 95% 62%)" }}>
                  ~{minsUntilFull}m
                </div>
                <div className="font-mono text-xs mb-1 text-dim">until fully booked</div>
                <div className="font-mono text-xs" style={{ color: confColor }}>
                  {confidence.toUpperCase()} confidence
                </div>
              </>
            ) : (
              <div className="font-mono text-xs text-dim pt-2">Not enough data yet</div>
            )}
          </div>
        </div>

        {/* Trip info + speed */}
        <div className="panel rounded-lg p-5 mb-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              ["DEPARTURE", bus.departsAt],
              ["FARE", `₹${bus.fare}`],
              ["SPEED", `${bus.speed} km/h`],
              ["DISTANCE", `${bus.distanceKm} km`],
            ].map(([k, v]) => (
              <div key={k}>
                <div className="label-caps text-dim mb-1" style={{ fontSize: 9 }}>{k}</div>
                <div className="font-mono text-sm" style={{ color: "hsl(160 10% 75%)" }}>{v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Booking */}
        {bus.availableSeats > 0 ? (
          <button onClick={() => setBooked(true)}
            className="btn-command w-full py-3 rounded-lg font-command tracking-widest"
            style={{ fontSize: 14 }}>
            RESERVE SEAT — ₹{bus.fare}
          </button>
        ) : (
          <div className="panel rounded-lg p-4 text-center">
            <p className="font-mono text-xs" style={{ color: "hsl(4 84% 68%)" }}>BUS FULLY BOOKED</p>
          </div>
        )}
      </div>
    </div>
  );
}
