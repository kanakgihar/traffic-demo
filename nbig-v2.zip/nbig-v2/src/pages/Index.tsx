/**
 * Index.tsx — Passenger Search (Command aesthetic)
 */
import { useState } from "react";
import { Search, MapPin, Bus, AlertTriangle, TrendingUp, Leaf, Zap, ArrowRight } from "lucide-react";
import { CITIES } from "@/data/buses";
import { useBusSimulation } from "@/hooks/useBusSimulation";
import { BusCard } from "@/components/BusCard";
import { Header } from "@/components/Header";

const QUICK: [string, string][] = [
  ["New Delhi","Jaipur"],["Mumbai","Pune"],["Bangalore","Chennai"],
  ["Hyderabad","Bangalore"],["Delhi","Chandigarh"],["Mumbai","Ahmedabad"],
];

export default function Index() {
  const [source, setSrc]   = useState("");
  const [dest, setDest]    = useState("");
  const [searched, search] = useState(false);
  const { searchBuses, stats } = useBusSimulation();
  const results = searched ? searchBuses(source, dest) : [];

  const go = () => { if (source.trim() && dest.trim()) search(true); };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Search hero */}
      <section className="relative overflow-hidden py-16 pb-24" style={{ background: "hsl(216 28% 5%)" }}>
        <div className="bg-command-grid absolute inset-0 pointer-events-none" />
        <div className="absolute inset-0 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 50% 60% at 50% 0%, hsl(152 80% 48% / 0.05) 0%, transparent 70%)" }} />

        <div className="container relative z-10 max-w-3xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-5 animate-fade-in">
            <span className="radar-ping" />
            <span className="label-caps text-radar">PASSENGER INTELLIGENCE</span>
          </div>
          <h1 className="font-command text-4xl sm:text-5xl mb-3 animate-fade-in delay-100" style={{ letterSpacing: "0.04em", color: "hsl(160 10% 90%)" }}>
            FIND YOUR BUS.
          </h1>
          <p className="font-mono text-sm mb-8 animate-fade-in delay-200" style={{ color: "hsl(216 12% 45%)" }}>
            Live seat availability · AI predictions · Real-time ETA
          </p>

          <div className="rounded-lg p-3 animate-scale-in delay-300"
            style={{ background: "hsl(216 24% 10%)", border: "1px solid hsl(152 80% 48% / 0.15)", boxShadow: "0 0 0 1px hsl(152 80% 48% / 0.05), 0 8px 32px rgba(0,0,0,0.4)" }}>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-dim" />
                <input list="src-list" placeholder="ORIGIN CITY" value={source}
                  onChange={e => { setSrc(e.target.value); search(false); }}
                  onKeyDown={e => e.key === "Enter" && go()}
                  className="input-command" />
                <datalist id="src-list">{CITIES.map(c => <option key={c} value={c} />)}</datalist>
              </div>
              <div className="relative flex-1">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-dim" />
                <input list="dst-list" placeholder="DESTINATION CITY" value={dest}
                  onChange={e => { setDest(e.target.value); search(false); }}
                  onKeyDown={e => e.key === "Enter" && go()}
                  className="input-command" />
                <datalist id="dst-list">{CITIES.map(c => <option key={c} value={c} />)}</datalist>
              </div>
              <button onClick={go} className="btn-command flex items-center justify-center gap-2 px-6 py-2.5 rounded" style={{ letterSpacing: "0.08em" }}>
                <Search className="h-4 w-4" /> SEARCH
              </button>
            </div>
          </div>

          {!searched && (
            <div className="mt-4 flex flex-wrap justify-center gap-2 animate-fade-in delay-400">
              {QUICK.map(([s, d]) => (
                <button key={`${s}-${d}`} onClick={() => { setSrc(s); setDest(d); search(true); }}
                  className="btn-outline flex items-center gap-1.5 px-3 py-1.5 rounded text-xs">
                  {s} <ArrowRight className="h-2.5 w-2.5" /> {d}
                </button>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* KPIs */}
      <section className="container py-6 -mt-8 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[
            { icon: <Bus className="h-4 w-4" />, l: "ACTIVE FLEET",   v: stats.total,          c: "radar" },
            { icon: <AlertTriangle className="h-4 w-4" />, l: "DELAYED", v: stats.delayed,      c: "critical" },
            { icon: <TrendingUp className="h-4 w-4" />, l: "UTILIZATION", v: `${stats.utilPct}%`, c: "amber" },
            { icon: <Leaf className="h-4 w-4" />, l: "CO₂ SAVED (KG)", v: stats.networkHealth.co2SavedKg, c: "radar" },
          ].map((k, i) => {
            const col = k.c === "radar" ? "hsl(152 80% 55%)" : k.c === "critical" ? "hsl(4 84% 68%)" : "hsl(43 95% 62%)";
            const bg  = k.c === "radar" ? "hsl(152 80% 48% / 0.08)" : k.c === "critical" ? "hsl(4 84% 55% / 0.08)" : "hsl(43 95% 52% / 0.08)";
            return (
              <div key={k.l} className="panel rounded-lg p-3 animate-fade-in-up" style={{ animationDelay: `${i*60}ms`, background: bg }}>
                <div className="flex items-center gap-1.5 mb-1" style={{ color: col }}>{k.icon}<span className="label-caps" style={{ color: col }}>{k.l}</span></div>
                <div className="font-command text-2xl font-bold" style={{ color: col }}>{k.v}</div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Results */}
      <section className="container pb-16">
        {searched ? (
          <div className="animate-fade-in">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="font-command text-xl tracking-wider" style={{ color: "hsl(160 10% 88%)" }}>
                  {results.length} UNIT{results.length !== 1 ? "S" : ""} FOUND
                </h2>
                <p className="font-mono text-xs text-dim mt-0.5">{source} → {dest} · SORTED BY ETA · AI ACTIVE</p>
              </div>
              <div className="flex items-center gap-2 chip-nominal rounded px-3 py-1.5">
                <Zap className="h-3 w-3" /> <span className="label-caps">AUTO-UPDATING</span>
              </div>
            </div>
            {results.length === 0 ? (
              <div className="panel rounded-lg p-12 text-center">
                <div className="label-caps text-dim mb-2">NO UNITS FOUND</div>
                <p className="font-mono text-xs text-dim">Try different city names from the autocomplete suggestions.</p>
              </div>
            ) : (
              <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
                {results.map((bus, i) => (
                  <div key={bus.id} className="animate-fade-in-up" style={{ animationDelay: `${i * 50}ms` }}>
                    <BusCard bus={bus} />
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="py-6 text-center">
            <div className="flex flex-wrap justify-center gap-5 mt-2">
              {["LIVE GPS","AI PREDICTION","DELAY DETECTION","ROUTE OPTIMIZATION","ENV ANALYTICS"].map(f => (
                <div key={f} className="flex items-center gap-1.5 label-caps text-dim">
                  <span className="w-1 h-1 rounded-full" style={{ background: "hsl(152 80% 48%)" }} />
                  {f}
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
