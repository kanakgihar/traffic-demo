/**
 * Dashboard.tsx — NBIG v2 Combined Authority Dashboard
 * Merges former Dashboard + CommandCenter into one tabbed view.
 * NEW: Replay mode, cascade alerts tab, CSV export, zone heatmap.
 */
import { useState, useMemo } from "react";
import { useBusSimulation } from "@/hooks/useBusSimulation";
import { predictSeatFill } from "@/services/aiPrediction";
import { generateOptimizations } from "@/services/intelligenceEngine";
import { Header } from "@/components/Header";
import {
  Bus, AlertTriangle, Activity, TrendingUp, Leaf, Zap,
  Navigation, CheckCircle, Users, Clock, Download,
  RefreshCw, ChevronRight, Eye, Gauge
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell
} from "recharts";

const ACTION_LABELS: Record<string, string> = {
  "add-frequency": "ADD FREQUENCY", "reroute": "REROUTE",
  "deploy-reserve": "DEPLOY RESERVE", "redistribute-load": "REDISTRIBUTE",
  "speed-advisory": "SPEED ADVISORY",
};

const ChartTip = ({ active, payload, label }: { active?: boolean; payload?: { fill?: string; color?: string; dataKey: string; value: number }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded px-3 py-2" style={{ background: "hsl(216 24% 12%)", border: "1px solid hsl(216 18% 20%)", fontFamily: "'IBM Plex Mono', monospace", fontSize: 11 }}>
      <div className="mb-1 text-dim">{label}</div>
      {payload.map((p, i) => <div key={i} style={{ color: p.fill ?? p.color }}>{p.dataKey}: <strong>{p.value}</strong></div>)}
    </div>
  );
};

type Tab = "overview" | "alerts" | "optimize" | "replay";

export default function Dashboard() {
  const {
    buses, stats, alerts, acknowledgeAlert,
    replayHistory, replayIndex, setReplay, isReplaying, exportCsv
  } = useBusSimulation();

  const [tab, setTab] = useState<Tab>("overview");
  const [alertFilter, setAlertFilter] = useState<"all" | "critical" | "warning">("all");

  const optimizations = useMemo(() => generateOptimizations(buses), [buses]);
  const nh = stats.networkHealth;

  const statusData = [
    { name: "ON-TIME",  value: stats.onTime,  fill: "hsl(152 80% 48%)" },
    { name: "DELAYED",  value: stats.delayed, fill: "hsl(4 84% 55%)"   },
    { name: "FILLING",  value: stats.filling, fill: "hsl(43 95% 52%)"  },
  ];

  const routeDist = useMemo(() => {
    const map: Record<string, number> = {};
    buses.forEach(b => { const k = `${b.source.slice(0,3)}-${b.destination.slice(0,3)}`; map[k] = (map[k] ?? 0) + 1; });
    return Object.entries(map).map(([name, count]) => ({ name, count })).slice(0, 8);
  }, [buses]);

  const fillingSoon = useMemo(() =>
    buses.map(b => ({ ...b, pred: predictSeatFill(b) }))
      .filter(b => b.pred.minsUntilFull !== null && b.pred.minsUntilFull <= 30)
      .sort((a, b) => (a.pred.minsUntilFull ?? 999) - (b.pred.minsUntilFull ?? 999))
      .slice(0, 8),
    [buses]
  );

  const filteredAlerts = alerts.filter(a =>
    !a.acknowledged && (alertFilter === "all" || a.severity === alertFilter)
  ).slice(0, 25);

  const urgentOpts = Object.entries(optimizations)
    .filter(([, o]) => o.priority === "urgent" || o.priority === "high")
    .slice(0, 6);

  const cascadeAlerts = alerts.filter(a => a.type === "cascade-risk" && !a.acknowledged);

  const scoreColor = nh.score >= 80 ? "hsl(152 80% 55%)" : nh.score >= 60 ? "hsl(43 95% 62%)" : "hsl(4 84% 68%)";

  const TABS: { id: Tab; label: string }[] = [
    { id: "overview", label: "OVERVIEW" },
    { id: "alerts", label: `ALERTS ${filteredAlerts.length > 0 ? `(${filteredAlerts.length})` : ""}` },
    { id: "optimize", label: "ROUTE OPTIMIZER" },
    { id: "replay", label: "REPLAY" },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container py-6 animate-fade-in">

        {/* Page header */}
        <div className="flex flex-wrap items-end justify-between gap-4 mb-5">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <h1 className="font-command text-2xl tracking-wider" style={{ color: "hsl(152 80% 55%)" }}>
                AUTHORITY DASHBOARD
              </h1>
              <div className="flex items-center gap-2 chip-nominal rounded px-3 py-1">
                <span className="radar-ping" />
                <span className="label-caps">{isReplaying ? "REPLAY" : "LIVE"}</span>
              </div>
            </div>
            <p className="font-mono text-xs text-dim">
              {stats.total} UNITS · {stats.totalPassengers.toLocaleString()} PASSENGERS · 5S REFRESH
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={exportCsv}
              className="flex items-center gap-1.5 px-4 py-2 rounded font-mono text-xs"
              style={{ border: "1px solid hsl(216 18% 22%)", color: "hsl(216 12% 55%)" }}>
              <Download className="h-3.5 w-3.5" /> EXPORT CSV
            </button>
            <div className="panel-radar rounded-lg px-4 py-2 text-center" style={{ minWidth: 100 }}>
              <div className="label-caps text-dim mb-0.5">HEALTH</div>
              <div className="font-command text-3xl font-bold" style={{ color: scoreColor }}>{nh.score}</div>
              <div className="label-caps" style={{ color: scoreColor, fontSize: 9 }}>/ 100</div>
            </div>
          </div>
        </div>

        {/* KPI strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-5">
          {[
            { label: "ON-TIME %",    value: `${nh.onTimePct}%`,        color: "hsl(152 80% 55%)", icon: <CheckCircle className="h-3.5 w-3.5" /> },
            { label: "UTILISATION",  value: `${nh.avgUtilization}%`,   color: "hsl(152 80% 55%)", icon: <Activity className="h-3.5 w-3.5" /> },
            { label: "CRIT. ALERTS", value: nh.criticalAlerts,         color: "hsl(4 84% 68%)",   icon: <AlertTriangle className="h-3.5 w-3.5" /> },
            { label: "OVERCROWDED",  value: stats.overcrowdingCount,   color: "hsl(43 95% 62%)",  icon: <Users className="h-3.5 w-3.5" /> },
            { label: "CO₂ SAVED",    value: `${nh.co2SavedKg}kg`,      color: "hsl(152 80% 48%)", icon: <Leaf className="h-3.5 w-3.5" /> },
            { label: "DEVIATIONS",   value: stats.deviated,            color: "hsl(43 95% 62%)",  icon: <Navigation className="h-3.5 w-3.5" /> },
          ].map(({ label, value, color, icon }) => (
            <div key={label} className="panel rounded-lg p-3">
              <div className="flex items-center gap-1.5 mb-2" style={{ color: "hsl(216 12% 40%)" }}>
                {icon}<span className="label-caps" style={{ fontSize: 9 }}>{label}</span>
              </div>
              <div className="font-command text-xl" style={{ color }}>{value}</div>
            </div>
          ))}
        </div>

        {/* Zone health */}
        <div className="panel rounded-lg p-4 mb-5">
          <div className="label-caps text-dim mb-3" style={{ fontSize: 10 }}>ZONE HEALTH — ON-TIME %</div>
          <div className="grid grid-cols-5 gap-2">
            {Object.entries(nh.zoneHealth).map(([zone, pct]) => {
              const c = pct >= 80 ? "hsl(152 80% 48%)" : pct >= 60 ? "hsl(43 95% 52%)" : "hsl(4 84% 55%)";
              return (
                <div key={zone} className="text-center">
                  <div className="label-caps text-dim mb-1" style={{ fontSize: 9 }}>{zone.toUpperCase()}</div>
                  <div className="h-1.5 rounded-full mb-1" style={{ background: "hsl(216 18% 14%)" }}>
                    <div className="h-1.5 rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: c }} />
                  </div>
                  <div className="font-mono text-xs font-semibold" style={{ color: c }}>{pct}%</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Tab nav */}
        <div className="flex gap-1 mb-5 border-b" style={{ borderColor: "hsl(216 18% 14%)" }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className="px-4 py-2 font-mono text-xs transition-colors"
              style={{
                color: tab === t.id ? "hsl(152 80% 55%)" : "hsl(216 12% 40%)",
                borderBottom: tab === t.id ? "2px solid hsl(152 80% 48%)" : "2px solid transparent",
                letterSpacing: "0.08em",
              }}>
              {t.label}
            </button>
          ))}
        </div>

        {/* ── TAB: OVERVIEW ── */}
        {tab === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Status chart */}
            <div className="panel rounded-lg p-4">
              <div className="label-caps text-dim mb-3" style={{ fontSize: 10 }}>FLEET STATUS BREAKDOWN</div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={statusData} margin={{ top: 4, right: 8, left: -24, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, fill: "hsl(216 12% 40%)" }} />
                  <YAxis tick={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, fill: "hsl(216 12% 40%)" }} />
                  <Tooltip content={<ChartTip />} />
                  <Bar dataKey="value" radius={[3, 3, 0, 0]}>
                    {statusData.map((d, i) => <Cell key={i} fill={d.fill} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Route distribution */}
            <div className="panel rounded-lg p-4">
              <div className="label-caps text-dim mb-3" style={{ fontSize: 10 }}>BUSES PER CORRIDOR</div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={routeDist} layout="vertical" margin={{ top: 0, right: 8, left: 32, bottom: 0 }}>
                  <XAxis type="number" tick={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 10, fill: "hsl(216 12% 40%)" }} />
                  <YAxis dataKey="name" type="category" width={64} tick={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9, fill: "hsl(216 12% 40%)" }} />
                  <Tooltip content={<ChartTip />} />
                  <Bar dataKey="count" fill="hsl(152 80% 40%)" radius={[0, 3, 3, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* AI seat predictions */}
            <div className="panel rounded-lg p-4 lg:col-span-2">
              <div className="label-caps text-dim mb-3" style={{ fontSize: 10 }}>AI SEAT-FILL PREDICTIONS — BUSES FILLING WITHIN 30 MIN</div>
              {fillingSoon.length === 0 ? (
                <p className="font-mono text-xs text-dim">No buses predicted to fill within 30 minutes.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full font-mono text-xs">
                    <thead>
                      <tr className="text-left" style={{ color: "hsl(216 12% 35%)" }}>
                        {["BUS","ROUTE","SEATS LEFT","FILLS IN","CONFIDENCE","DEMAND"].map(h => (
                          <th key={h} className="pb-2 pr-4 label-caps" style={{ fontSize: 9 }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {fillingSoon.map(b => {
                        const confColor = b.pred.confidence === "high" ? "hsl(152 80% 55%)" : b.pred.confidence === "medium" ? "hsl(43 95% 62%)" : "hsl(216 12% 45%)";
                        return (
                          <tr key={b.id} style={{ borderTop: "1px solid hsl(216 18% 14%)" }}>
                            <td className="py-2 pr-4" style={{ color: "hsl(160 10% 75%)" }}>{b.busNumber}</td>
                            <td className="py-2 pr-4 text-dim">{b.source.slice(0,3)}→{b.destination.slice(0,3)}</td>
                            <td className="py-2 pr-4" style={{ color: b.availableSeats < 5 ? "hsl(4 84% 68%)" : "hsl(43 95% 62%)" }}>{b.availableSeats}</td>
                            <td className="py-2 pr-4" style={{ color: "hsl(4 84% 68%)" }}>~{b.pred.minsUntilFull}m</td>
                            <td className="py-2 pr-4" style={{ color: confColor }}>{b.pred.confidence.toUpperCase()}</td>
                            <td className="py-2 pr-4" style={{ color: b.demandMultiplier > 1.4 ? "hsl(43 95% 62%)" : "hsl(216 12% 45%)" }}>{b.demandMultiplier.toFixed(2)}×</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TAB: ALERTS ── */}
        {tab === "alerts" && (
          <div>
            <div className="flex items-center gap-3 mb-4">
              {(["all","critical","warning"] as const).map(f => (
                <button key={f} onClick={() => setAlertFilter(f)}
                  className="px-3 py-1 rounded font-mono text-xs"
                  style={{
                    background: alertFilter === f ? "hsl(216 24% 14%)" : "transparent",
                    color: alertFilter === f ? "hsl(152 80% 55%)" : "hsl(216 12% 45%)",
                    border: "1px solid hsl(216 18% 20%)",
                    letterSpacing: "0.08em",
                  }}>
                  {f.toUpperCase()}
                </button>
              ))}
              {cascadeAlerts.length > 0 && (
                <div className="flex items-center gap-2 ml-4 px-3 py-1 rounded" style={{ background: "hsl(43 95% 52% / 0.1)", border: "1px solid hsl(43 95% 52% / 0.3)" }}>
                  <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "hsl(43 95% 62%)" }} />
                  <span className="font-mono text-xs" style={{ color: "hsl(43 95% 62%)" }}>{cascadeAlerts.length} CASCADE RISK{cascadeAlerts.length > 1 ? "S" : ""}</span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              {filteredAlerts.length === 0 && (
                <div className="panel rounded-lg p-6 text-center">
                  <CheckCircle className="h-8 w-8 mx-auto mb-2 text-radar" />
                  <p className="font-mono text-xs text-dim">No active alerts matching filter.</p>
                </div>
              )}
              {filteredAlerts.map(alert => {
                const isCrit = alert.severity === "critical";
                const isCascade = alert.type === "cascade-risk";
                return (
                  <div key={alert.id} className="panel rounded-lg p-4 flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5">
                        <AlertTriangle className="h-4 w-4" style={{ color: isCrit ? "hsl(4 84% 68%)" : isCascade ? "hsl(270 80% 65%)" : "hsl(43 95% 62%)" }} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="label-caps" style={{ fontSize: 9, color: isCrit ? "hsl(4 84% 68%)" : isCascade ? "hsl(270 80% 65%)" : "hsl(43 95% 62%)" }}>
                            {isCascade ? "CASCADE RISK" : alert.severity.toUpperCase()} · {alert.type.replace("-"," ").toUpperCase()}
                          </span>
                        </div>
                        <p className="font-mono text-xs" style={{ color: "hsl(160 10% 70%)" }}>{alert.message}</p>
                        <p className="font-mono mt-1" style={{ color: "hsl(216 12% 35%)", fontSize: 10 }}>
                          {new Date(alert.timestamp).toLocaleTimeString("en-IN", { hour12: false })}
                        </p>
                      </div>
                    </div>
                    <button onClick={() => acknowledgeAlert(alert.id)}
                      className="flex-shrink-0 px-2 py-1 rounded font-mono text-xs"
                      style={{ border: "1px solid hsl(216 18% 22%)", color: "hsl(216 12% 50%)" }}>
                      ACK
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── TAB: ROUTE OPTIMIZER ── */}
        {tab === "optimize" && (
          <div>
            <p className="font-mono text-xs text-dim mb-4">
              Rule-based optimization engine. Thresholds: occupancy &gt;88%+demand&gt;1.3× → add frequency · 2+ delayed+speed&lt;35 → reroute · occupancy&lt;35% → redistribute.
            </p>
            <div className="space-y-3">
              {urgentOpts.length === 0 && (
                <div className="panel rounded-lg p-6 text-center">
                  <CheckCircle className="h-8 w-8 mx-auto mb-2 text-radar" />
                  <p className="font-mono text-xs text-dim">No urgent optimizations. Network is balanced.</p>
                </div>
              )}
              {urgentOpts.map(([routeKey, opt]) => {
                const priColor = opt.priority === "urgent" ? "hsl(4 84% 68%)" : opt.priority === "high" ? "hsl(43 95% 62%)" : "hsl(152 80% 48%)";
                return (
                  <div key={routeKey} className="panel rounded-lg p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="label-caps px-2 py-0.5 rounded" style={{ fontSize: 9, color: priColor, border: `1px solid ${priColor}33` }}>
                            {opt.priority.toUpperCase()}
                          </span>
                          <span className="font-command text-sm" style={{ color: "hsl(160 10% 75%)" }}>{routeKey}</span>
                          <span className="label-caps px-2 py-0.5 rounded" style={{ fontSize: 9, background: "hsl(152 80% 48% / 0.1)", color: "hsl(152 80% 55%)", border: "1px solid hsl(152 80% 48% / 0.3)" }}>
                            {ACTION_LABELS[opt.action]}
                          </span>
                        </div>
                        <p className="font-mono text-xs text-dim mb-1">{opt.reason}</p>
                        <p className="font-mono text-xs" style={{ color: "hsl(152 80% 48%)" }}>{opt.estimatedImpact}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="label-caps text-dim mb-1" style={{ fontSize: 9 }}>CONFIDENCE</div>
                        <div className="font-command text-xl" style={{ color: opt.confidence >= 80 ? "hsl(152 80% 55%)" : "hsl(43 95% 62%)" }}>{opt.confidence}%</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── TAB: REPLAY ── */}
        {tab === "replay" && (
          <div>
            <div className="panel rounded-lg p-5 mb-4">
              <div className="label-caps text-dim mb-3" style={{ fontSize: 10 }}>FLEET REPLAY — LAST {replayHistory.length} TICKS ({Math.round(replayHistory.length * 5 / 60)} MIN)</div>
              {replayHistory.length < 2 ? (
                <p className="font-mono text-xs text-dim">Accumulating history… check back in 30 seconds.</p>
              ) : (
                <>
                  <div className="flex items-center gap-4 mb-3">
                    <span className="font-mono text-xs text-dim">OLDEST</span>
                    <input type="range" min={0} max={replayHistory.length - 1}
                      value={replayIndex ?? replayHistory.length - 1}
                      onChange={e => setReplay(Number(e.target.value))}
                      className="flex-1" />
                    <span className="font-mono text-xs text-dim">NOW</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button onClick={() => setReplay(null)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded font-mono text-xs"
                      style={{ background: !isReplaying ? "hsl(152 80% 48% / 0.15)" : "transparent", border: "1px solid hsl(216 18% 22%)", color: !isReplaying ? "hsl(152 80% 55%)" : "hsl(216 12% 50%)" }}>
                      <RefreshCw className="h-3 w-3" /> LIVE
                    </button>
                    {isReplaying && (
                      <span className="font-mono text-xs" style={{ color: "hsl(43 95% 62%)" }}>
                        <Eye className="h-3.5 w-3.5 inline mr-1" />
                        Viewing tick {(replayIndex ?? 0) + 1} of {replayHistory.length} ({Math.round(((replayIndex ?? 0) + 1) * 5 / 60 * 10) / 10}m ago)
                      </span>
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Snapshot table */}
            <div className="panel rounded-lg p-4">
              <div className="label-caps text-dim mb-3" style={{ fontSize: 10 }}>
                {isReplaying ? `SNAPSHOT AT TICK ${(replayIndex ?? 0) + 1}` : "LIVE FLEET SNAPSHOT"}
              </div>
              <div className="overflow-x-auto">
                <table className="w-full font-mono text-xs">
                  <thead>
                    <tr style={{ color: "hsl(216 12% 35%)" }}>
                      {["BUS","ROUTE","STATUS","SEATS","ETA","SPEED","OCC. RISK"].map(h => (
                        <th key={h} className="text-left pb-2 pr-4 label-caps" style={{ fontSize: 9 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {buses.slice(0, 20).map(b => {
                      const statusColor = b.status === "on-time" ? "hsl(152 80% 55%)" : b.status === "delayed" ? "hsl(4 84% 68%)" : "hsl(43 95% 62%)";
                      return (
                        <tr key={b.id} style={{ borderTop: "1px solid hsl(216 18% 14%)" }}>
                          <td className="py-1.5 pr-4" style={{ color: "hsl(160 10% 75%)" }}>{b.busNumber}</td>
                          <td className="py-1.5 pr-4 text-dim">{b.source.slice(0,3)}→{b.destination.slice(0,3)}</td>
                          <td className="py-1.5 pr-4" style={{ color: statusColor }}>{b.status.toUpperCase()}</td>
                          <td className="py-1.5 pr-4" style={{ color: b.availableSeats < 5 ? "hsl(4 84% 68%)" : "hsl(216 12% 55%)" }}>{b.availableSeats}/{b.totalSeats}</td>
                          <td className="py-1.5 pr-4 text-dim">{b.etaMinutes}m</td>
                          <td className="py-1.5 pr-4 text-dim">{b.speed}km/h</td>
                          <td className="py-1.5" style={{ color: b.overcrowdingRisk > 80 ? "hsl(4 84% 68%)" : b.overcrowdingRisk > 60 ? "hsl(43 95% 62%)" : "hsl(152 80% 48%)" }}>
                            {b.overcrowdingRisk}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
