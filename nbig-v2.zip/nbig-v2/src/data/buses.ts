/**
 * buses.ts — NBIG v2 Data Layer
 * Cleaned: removed engineTempScore (cosmetic only).
 * Added: lat/lng per stop for live map, time-of-day demand model.
 */

export type BusStatus = "on-time" | "delayed" | "filling-fast" | "critical" | "diverted";
export type AlertSeverity = "info" | "warning" | "critical";
export type OptimizationAction =
  | "add-frequency"
  | "reroute"
  | "deploy-reserve"
  | "redistribute-load"
  | "speed-advisory";

export interface LatLng { lat: number; lng: number }

export interface RouteOptimization {
  action: OptimizationAction;
  reason: string;
  estimatedImpact: string;
  confidence: number;
  priority: "low" | "medium" | "high" | "urgent";
}

export interface SystemAlert {
  id: string;
  busId?: string;
  routeKey?: string;
  severity: AlertSeverity;
  type: "overcrowding" | "delay-cascade" | "deviation" | "demand-spike" | "cascade-risk";
  message: string;
  timestamp: number;
  acknowledged: boolean;
}

export interface Bus {
  id: string;
  busNumber: string;
  routeKey: string;
  source: string;
  destination: string;
  route: string[];
  distanceKm: number;
  totalSeats: number;
  availableSeats: number;
  seatHistory: number[];
  etaMinutes: number;
  scheduledEta: number;
  status: BusStatus;
  driver: string;
  speed: number;
  departsAt: string;
  fare: number;
  deviationKm: number;
  isDeviated: boolean;
  overcrowdingRisk: number;
  fuelLevelPct: number;
  passengerBoardingRate: number;
  demandMultiplier: number;
  optimization?: RouteOptimization;
  alertIds: string[];
  stateCode: string;
  currentLat: number;
  currentLng: number;
  progressPct: number;
}

export const CITY_COORDS: Record<string, LatLng> = {
  "New Delhi":   { lat: 28.6139, lng: 77.2090 },
  "Mumbai":      { lat: 19.0760, lng: 72.8777 },
  "Bangalore":   { lat: 12.9716, lng: 77.5946 },
  "Chennai":     { lat: 13.0827, lng: 80.2707 },
  "Kolkata":     { lat: 22.5726, lng: 88.3639 },
  "Hyderabad":   { lat: 17.3850, lng: 78.4867 },
  "Pune":        { lat: 18.5204, lng: 73.8567 },
  "Ahmedabad":   { lat: 23.0225, lng: 72.5714 },
  "Jaipur":      { lat: 26.9124, lng: 75.7873 },
  "Lucknow":     { lat: 26.8467, lng: 80.9462 },
  "Chandigarh":  { lat: 30.7333, lng: 76.7794 },
  "Bhopal":      { lat: 23.2599, lng: 77.4126 },
  "Patna":       { lat: 25.5941, lng: 85.1376 },
  "Kochi":       { lat: 9.9312,  lng: 76.2673 },
  "Guwahati":    { lat: 26.1445, lng: 91.7362 },
  "Gurgaon":     { lat: 28.4595, lng: 77.0266 },
  "Neemrana":    { lat: 27.9867, lng: 76.3820 },
  "Behror":      { lat: 27.8900, lng: 76.2900 },
  "Shahpura":    { lat: 27.3900, lng: 75.9600 },
  "Panvel":      { lat: 18.9894, lng: 73.1175 },
  "Lonavala":    { lat: 18.7481, lng: 73.4072 },
  "Khandala":    { lat: 18.7600, lng: 73.3900 },
  "Hosur":       { lat: 12.7409, lng: 77.8253 },
  "Krishnagiri": { lat: 12.5186, lng: 78.2137 },
  "Vellore":     { lat: 12.9165, lng: 79.1325 },
  "Kanchipuram": { lat: 12.8342, lng: 79.7036 },
  "Durgapur":    { lat: 23.5204, lng: 87.3119 },
  "Asansol":     { lat: 23.6889, lng: 86.9661 },
  "Dhanbad":     { lat: 23.7957, lng: 86.4304 },
  "Gaya":        { lat: 24.7914, lng: 84.9994 },
  "Mahbubnagar": { lat: 16.7488, lng: 78.0036 },
  "Kurnool":     { lat: 15.8281, lng: 78.0373 },
  "Anantapur":   { lat: 14.6819, lng: 77.6006 },
  "Panipat":     { lat: 29.3909, lng: 76.9635 },
  "Karnal":      { lat: 29.6857, lng: 76.9905 },
  "Ambala":      { lat: 30.3782, lng: 76.7767 },
  "Vapi":        { lat: 20.3717, lng: 72.9086 },
  "Surat":       { lat: 21.1702, lng: 72.8311 },
  "Vadodara":    { lat: 22.3072, lng: 73.1812 },
  "Salem":       { lat: 11.6643, lng: 78.1460 },
  "Coimbatore":  { lat: 11.0168, lng: 76.9558 },
  "Thrissur":    { lat: 10.5276, lng: 76.2144 },
  "Sultanpur":   { lat: 26.2648, lng: 82.0727 },
  "Varanasi":    { lat: 25.3176, lng: 82.9739 },
  "Mughal Sarai":{ lat: 25.2800, lng: 83.1200 },
  "Ajmer":       { lat: 26.4499, lng: 74.6399 },
  "Udaipur":     { lat: 24.5854, lng: 73.7125 },
  "Palanpur":    { lat: 24.1725, lng: 72.4382 },
  "Indore":      { lat: 22.7196, lng: 75.8577 },
  "Dhule":       { lat: 20.9042, lng: 74.7749 },
  "Nashik":      { lat: 19.9975, lng: 73.7898 },
  "Siliguri":    { lat: 26.7271, lng: 88.3953 },
  "Malda":       { lat: 25.0108, lng: 88.1418 },
  "Murshidabad": { lat: 24.1834, lng: 88.2705 },
};

export const STATE_CODES: Record<string, string> = {
  "New Delhi": "DL", "Jaipur": "RJ", "Chandigarh": "PB",
  "Mumbai": "MH", "Pune": "MH", "Ahmedabad": "GJ",
  "Bangalore": "KA", "Chennai": "TN", "Kochi": "KL",
  "Kolkata": "WB", "Patna": "BR", "Guwahati": "AS",
  "Hyderabad": "TS", "Lucknow": "UP", "Bhopal": "MP",
};

const DRIVER_NAMES = [
  "Rajesh Kumar", "Sunil Sharma", "Amit Patel", "Vijay Singh",
  "Manoj Verma", "Deepak Yadav", "Arun Gupta", "Sanjay Mishra",
  "Pradeep Nair", "Ravi Shankar", "Mohan Das", "Kishore Reddy",
];

export const ROUTES: Record<string, { stops: string[]; distanceKm: number; zone: string }> = {
  "New Delhi-Jaipur":    { stops: ["New Delhi","Gurgaon","Neemrana","Behror","Shahpura","Jaipur"],        distanceKm: 280, zone: "North" },
  "Mumbai-Pune":         { stops: ["Mumbai","Panvel","Lonavala","Khandala","Pune"],                        distanceKm: 148, zone: "West"  },
  "Bangalore-Chennai":   { stops: ["Bangalore","Hosur","Krishnagiri","Vellore","Kanchipuram","Chennai"],   distanceKm: 346, zone: "South" },
  "Kolkata-Patna":       { stops: ["Kolkata","Durgapur","Asansol","Dhanbad","Gaya","Patna"],              distanceKm: 540, zone: "East"  },
  "Hyderabad-Bangalore": { stops: ["Hyderabad","Mahbubnagar","Kurnool","Anantapur","Bangalore"],           distanceKm: 570, zone: "South" },
  "Delhi-Chandigarh":    { stops: ["New Delhi","Panipat","Karnal","Ambala","Chandigarh"],                  distanceKm: 250, zone: "North" },
  "Mumbai-Ahmedabad":    { stops: ["Mumbai","Vapi","Surat","Vadodara","Ahmedabad"],                        distanceKm: 524, zone: "West"  },
  "Chennai-Kochi":       { stops: ["Chennai","Salem","Coimbatore","Thrissur","Kochi"],                     distanceKm: 680, zone: "South" },
  "Lucknow-Patna":       { stops: ["Lucknow","Sultanpur","Varanasi","Mughal Sarai","Patna"],               distanceKm: 510, zone: "Central"},
  "Jaipur-Ahmedabad":    { stops: ["Jaipur","Ajmer","Udaipur","Palanpur","Ahmedabad"],                     distanceKm: 660, zone: "West"  },
  "Bhopal-Pune":         { stops: ["Bhopal","Indore","Dhule","Nashik","Pune"],                             distanceKm: 745, zone: "Central"},
  "Guwahati-Kolkata":    { stops: ["Guwahati","Siliguri","Malda","Murshidabad","Kolkata"],                 distanceKm: 990, zone: "East"  },
};

/** Interpolate lat/lng along route stops based on progress 0–100 */
export function interpolatePosition(stops: string[], progressPct: number): LatLng {
  const n = stops.length;
  if (n < 2) return CITY_COORDS[stops[0]] ?? { lat: 20.5937, lng: 78.9629 };
  const segCount = n - 1;
  const totalProgress = Math.min(progressPct / 100, 0.999);
  const segIndex = Math.min(Math.floor(totalProgress * segCount), segCount - 1);
  const segProgress = totalProgress * segCount - segIndex;
  const from = CITY_COORDS[stops[segIndex]]     ?? { lat: 20, lng: 78 };
  const to   = CITY_COORDS[stops[segIndex + 1]] ?? from;
  return {
    lat: from.lat + (to.lat - from.lat) * segProgress,
    lng: from.lng + (to.lng - from.lng) * segProgress,
  };
}

/** Time-of-day demand multiplier — peaks at 8 AM and 6 PM */
export function getDemandMultiplier(): number {
  const h = new Date().getHours();
  if (h >= 7  && h < 9)  return 1.6 + Math.random() * 0.4;
  if (h >= 17 && h < 19) return 1.5 + Math.random() * 0.5;
  if (h >= 22 || h < 5)  return 0.65 + Math.random() * 0.2;
  return 1.0 + Math.random() * 0.3;
}

const NOMINAL_SPEED_KMH = 65;

function generateBuses(): Bus[] {
  const buses: Bus[] = [];
  let id = 1;

  Object.entries(ROUTES).forEach(([key, { stops, distanceKm }]) => {
    const source      = stops[0];
    const destination = stops[stops.length - 1];

    for (let i = 0; i < 3; i++) {
      const totalSeats  = ([40, 45, 50] as const)[Math.floor(Math.random() * 3)];
      const available   = Math.floor(Math.random() * totalSeats * 0.6) + 2;
      const nominalEta  = Math.round((distanceKm / NOMINAL_SPEED_KMH) * 60);
      const etaVariance = Math.floor(Math.random() * 30) - 15;
      const speed       = Math.floor(Math.random() * 30) + 50;
      const occupancy   = 1 - available / totalSeats;
      const progressPct = Math.random() * 75 + 5;
      const pos         = interpolatePosition(stops, progressPct);

      buses.push({
        id:              `BUS-${String(id).padStart(4, "0")}`,
        busNumber:       `NB-${1000 + id}`,
        routeKey:        key,
        source,
        destination,
        route:           stops,
        distanceKm,
        totalSeats,
        availableSeats:  available,
        seatHistory:     [available, available, available],
        etaMinutes:      Math.max(10, nominalEta + etaVariance),
        scheduledEta:    nominalEta,
        status:          "on-time",
        driver:          DRIVER_NAMES[Math.floor(Math.random() * DRIVER_NAMES.length)],
        speed,
        departsAt:       `${String(5 + Math.floor(Math.random() * 16)).padStart(2, "0")}:${["00","15","30","45"][Math.floor(Math.random() * 4)]}`,
        fare:            Math.floor(Math.random() * 800) + 200,
        deviationKm:     0,
        isDeviated:      false,
        overcrowdingRisk: Math.round(occupancy * 80 + Math.random() * 20),
        fuelLevelPct:    Math.floor(Math.random() * 40) + 50,
        passengerBoardingRate: parseFloat((Math.random() * 3 + 0.5).toFixed(1)),
        demandMultiplier: getDemandMultiplier(),
        alertIds:        [],
        stateCode:       STATE_CODES[source] ?? "IN",
        currentLat:      pos.lat,
        currentLng:      pos.lng,
        progressPct,
      });
      id++;
    }
  });

  return buses;
}

export const MOCK_BUSES: Bus[] = generateBuses();

export const CITIES = [
  "New Delhi", "Mumbai", "Bangalore", "Chennai", "Kolkata",
  "Hyderabad", "Pune", "Ahmedabad", "Jaipur", "Lucknow",
  "Chandigarh", "Bhopal", "Patna", "Kochi", "Guwahati",
];
