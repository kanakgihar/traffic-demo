/**
 * etaService.ts — ETA Calculation Service
 *
 * Computes a smoothed, speed-based ETA for each bus using:
 *   remainingKm / currentSpeed × 60 min
 *
 * The result is then blended with the current ETA to reduce tick-to-tick
 * jitter (exponential moving average style).
 *
 * In production: replace with GTFS-RT (General Transit Feed Spec Realtime)
 * or a HERE/Google Directions live traffic feed.
 */

import type { Bus } from "@/data/buses";

/** Weight given to the speed-based ETA vs the previous ETA in the blend */
const SPEED_WEIGHT = 0.6;
const PREV_WEIGHT  = 0.4;

/**
 * Returns a refined ETA in minutes for the given bus.
 *
 * @param bus         Current bus state
 * @param rawEtaDelta Small random delta that drives organic ETA variation
 */
export function calculateEta(bus: Bus, rawEtaDelta: number = 0): number {
  // Estimate journey completion ratio from remaining ETA vs scheduled ETA
  const progress    = Math.max(0, 1 - bus.etaMinutes / (bus.scheduledEta || 60));
  const remainingKm = bus.distanceKm * (1 - progress);

  // Speed-based estimate
  const speedBased  = bus.speed > 0
    ? (remainingKm / bus.speed) * 60
    : bus.etaMinutes; // fallback if speed data is missing

  // Smoothed blend: avoids jagged ETA oscillation on every tick
  const prevEta = Math.max(0, bus.etaMinutes + rawEtaDelta);
  const blended = Math.round(speedBased * SPEED_WEIGHT + prevEta * PREV_WEIGHT);

  return Math.max(0, blended);
}
