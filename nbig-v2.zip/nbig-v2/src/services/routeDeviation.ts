/**
 * routeDeviation.ts — Route Deviation Detection Service
 *
 * Simulates GPS corridor monitoring by applying a random walk to each
 * bus's deviationKm value each simulation tick.  When deviationKm exceeds
 * DEVIATION_THRESHOLD the bus is flagged isDeviated = true.
 *
 * In production: replace with a Haversine (or Vincenty) distance check
 * from the bus's live GPS coordinates to the nearest point on the
 * pre-defined route polyline. Use a tolerance corridor of ~0.5 km.
 */

export interface DeviationResult {
  deviationKm: number;
  isDeviated: boolean;
}

/** Deviation distance that triggers an alert (km off expected corridor) */
const DEVIATION_THRESHOLD_KM = 2.5;

/** Max deviation the simulation will allow before clamping */
const MAX_DEVIATION_KM = 8;

/**
 * Applies one tick of simulated GPS drift to the bus's current deviation.
 *
 * The random walk is slightly biased toward returning to zero (mean-reverting)
 * so persistent false alerts are avoided.
 */
export function simulateDeviation(currentDeviationKm: number): DeviationResult {
  // Small mean-reverting random walk: slight bias toward 0 when already deviated
  const bias       = currentDeviationKm > DEVIATION_THRESHOLD_KM ? -0.15 : 0;
  const randomWalk = (Math.random() - 0.48 + bias) * 0.8;

  const deviationKm = parseFloat(
    Math.max(0, Math.min(MAX_DEVIATION_KM, currentDeviationKm + randomWalk)).toFixed(2)
  );

  return {
    deviationKm,
    isDeviated: deviationKm > DEVIATION_THRESHOLD_KM,
  };
}
