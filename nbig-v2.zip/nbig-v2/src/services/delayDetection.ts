/**
 * delayDetection.ts — Delay Detection Service
 *
 * Determines bus status using two independent signals:
 *
 *   1. Speed signal  — bus is travelling < SPEED_THRESHOLD km/h
 *      (indicates traffic jam, breakdown, or congestion)
 *
 *   2. Schedule signal — live ETA exceeds scheduledEta by > SCHEDULE_SLIP_FACTOR
 *      (indicates the bus is running behind its timetable)
 *
 * Either signal alone is sufficient to mark a bus as "delayed".
 * "filling-fast" takes priority when very few seats remain.
 *
 * In production: combine with GTFS-RT trip updates and driver events.
 */

import type { Bus, BusStatus } from "@/data/buses";

/** Buses slower than this are flagged as delayed regardless of schedule */
const SPEED_THRESHOLD_KMH = 30;

/** ETA must exceed scheduledEta by this factor to trigger a schedule-based delay */
const SCHEDULE_SLIP_FACTOR = 1.10; // 10% over schedule

/** Seat count at or below this triggers "filling-fast" (overrides other signals) */
const FILLING_FAST_THRESHOLD = 5;

/**
 * Returns the computed BusStatus for the given bus state.
 */
export function detectStatus(bus: Bus): BusStatus {
  // Filling fast takes highest priority
  if (bus.availableSeats <= FILLING_FAST_THRESHOLD) return "filling-fast";

  const speedDelay    = bus.speed < SPEED_THRESHOLD_KMH;
  const scheduleDelay = bus.etaMinutes > (bus.scheduledEta * SCHEDULE_SLIP_FACTOR);

  if (speedDelay || scheduleDelay) return "delayed";
  return "on-time";
}
