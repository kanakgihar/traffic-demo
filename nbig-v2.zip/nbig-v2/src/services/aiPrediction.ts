/**
 * aiPrediction.ts — Seat Fill Rate Extrapolation
 *
 * Predicts when a bus will be fully booked using the rate at which seats
 * are being taken, computed from a rolling history ring buffer.
 *
 * Algorithm: rate extrapolation (seats lost per tick → ticks until empty).
 * This is NOT a regression model. In production, replace with XGBoost or LSTM
 * trained on historical booking patterns per route × time-of-day.
 *
 * Confidence levels are based on ring buffer depth — shallow buffers
 * give unreliable slopes.
 */

import type { Bus } from "@/data/buses";

export interface SeatPrediction {
  /** Minutes until fully booked, or null if trend is flat/unknown */
  minsUntilFull: number | null;
  /** Confidence based on ring buffer depth */
  confidence: "high" | "medium" | "low";
}

/**
 * Predicts seat fill time from the bus's seatHistory ring buffer.
 *
 * Steps:
 *  1. Compute average seats lost per 5s tick across the history window.
 *  2. Divide remaining seats by that rate → ticks until empty.
 *  3. Convert ticks × 5s → minutes.
 *  4. Confidence: high ≥6 ticks, medium ≥3, low <3.
 */
export function predictSeatFill(bus: Bus): SeatPrediction {
  const { availableSeats, seatHistory } = bus;

  if (availableSeats === 0) return { minsUntilFull: 0, confidence: "high" };
  if (seatHistory.length < 2) return { minsUntilFull: null, confidence: "low" };

  let totalLoss = 0;
  for (let i = 1; i < seatHistory.length; i++) {
    totalLoss += Math.max(0, seatHistory[i - 1] - seatHistory[i]);
  }

  const avgLossPerTick = totalLoss / (seatHistory.length - 1);
  if (avgLossPerTick <= 0) return { minsUntilFull: null, confidence: "low" };

  const ticksUntilFull = availableSeats / avgLossPerTick;
  const minsUntilFull  = Math.round((ticksUntilFull * 5) / 60);

  const confidence: SeatPrediction["confidence"] =
    seatHistory.length >= 6 ? "high" :
    seatHistory.length >= 3 ? "medium" : "low";

  return { minsUntilFull: Math.min(minsUntilFull, 999), confidence };
}
