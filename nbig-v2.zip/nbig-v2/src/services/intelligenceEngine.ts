/**
 * intelligenceEngine.ts — NBIG v2 Intelligence Engine
 *
 * Rule-based optimization engine (not ML). Thresholds are documented below.
 * Generates alerts, route optimizations, cascade risk signals, and network health.
 * Alert deduplication: keyed on busId+type so the same condition doesn't spam.
 */

import type { Bus, SystemAlert, RouteOptimization, OptimizationAction } from "@/data/buses";
import { ROUTES } from "@/data/buses";
import { predictSeatFill } from "./aiPrediction";

let alertCounter = 0;
const activeAlertKeys = new Set<string>();   // dedup key: busId+type

function makeAlert(partial: Omit<SystemAlert, "id" | "timestamp" | "acknowledged">): SystemAlert {
  return {
    ...partial,
    id: `ALT-${String(++alertCounter).padStart(5, "0")}`,
    timestamp: Date.now(),
    acknowledged: false,
  };
}

/** Clears dedup set on each full alert generation cycle */
export function resetAlertKeys() { activeAlertKeys.clear(); }

export function generateAlerts(buses: Bus[]): SystemAlert[] {
  const alerts: SystemAlert[] = [];

  buses.forEach(bus => {
    const occupancyPct = (1 - bus.availableSeats / bus.totalSeats) * 100;

    // Overcrowding
    if (occupancyPct >= 95) {
      const key = `${bus.id}-overcrowding-critical`;
      if (!activeAlertKeys.has(key)) {
        activeAlertKeys.add(key);
        alerts.push(makeAlert({
          busId: bus.id, routeKey: bus.routeKey, severity: "critical",
          type: "overcrowding",
          message: `${bus.busNumber} at ${occupancyPct.toFixed(0)}% capacity — standing room only on ${bus.source}→${bus.destination}`,
        }));
      }
    } else if (occupancyPct >= 85) {
      const key = `${bus.id}-overcrowding-warning`;
      if (!activeAlertKeys.has(key)) {
        activeAlertKeys.add(key);
        alerts.push(makeAlert({
          busId: bus.id, routeKey: bus.routeKey, severity: "warning",
          type: "overcrowding",
          message: `${bus.busNumber} approaching capacity (${bus.availableSeats} seats left) — ${bus.source}→${bus.destination}`,
        }));
      }
    }

    // Route deviation
    if (bus.isDeviated && bus.deviationKm > 3.5) {
      const key = `${bus.id}-deviation`;
      if (!activeAlertKeys.has(key)) {
        activeAlertKeys.add(key);
        alerts.push(makeAlert({
          busId: bus.id, routeKey: bus.routeKey, severity: "warning",
          type: "deviation",
          message: `${bus.busNumber} is ${bus.deviationKm.toFixed(1)} km off route corridor — ${bus.source}→${bus.destination}`,
        }));
      }
    }

    // Schedule slip
    if (bus.status === "delayed" && bus.etaMinutes > bus.scheduledEta * 1.3) {
      const key = `${bus.id}-delay-cascade`;
      if (!activeAlertKeys.has(key)) {
        activeAlertKeys.add(key);
        alerts.push(makeAlert({
          busId: bus.id, routeKey: bus.routeKey, severity: "warning",
          type: "delay-cascade",
          message: `${bus.busNumber} running +${bus.etaMinutes - bus.scheduledEta}m behind schedule — cascade risk to connecting services`,
        }));
      }
    }

    // AI seat fill prediction
    const pred = predictSeatFill(bus);
    if (pred.minsUntilFull !== null && pred.minsUntilFull <= 10 && pred.confidence !== "low") {
      const key = `${bus.id}-demand-spike`;
      if (!activeAlertKeys.has(key)) {
        activeAlertKeys.add(key);
        alerts.push(makeAlert({
          busId: bus.id, routeKey: bus.routeKey, severity: "warning",
          type: "demand-spike",
          message: `Prediction: ${bus.busNumber} full in ~${pred.minsUntilFull}m (${pred.confidence} confidence) — pre-position reserve bus`,
        }));
      }
    }
  });

  return alerts;
}

/**
 * Cascade risk detection: if Bus A is delayed at a city, find buses departing
 * from that same city (downstream connections) and flag them as cascade risk.
 */
export function detectCascadeRisks(buses: Bus[]): SystemAlert[] {
  const alerts: SystemAlert[] = [];
  const delayedAtCity = new Set<string>();

  buses
    .filter(b => b.status === "delayed" && b.etaMinutes > b.scheduledEta * 1.2)
    .forEach(b => {
      // The bus is heading TO its destination late — flag the destination city
      delayedAtCity.add(b.destination);
      // Also flag intermediate stops if well into journey
      if (b.progressPct > 40 && b.route.length > 2) {
        const midIdx = Math.floor(b.route.length / 2);
        delayedAtCity.add(b.route[midIdx]);
      }
    });

  if (delayedAtCity.size === 0) return alerts;

  buses.forEach(bus => {
    if (delayedAtCity.has(bus.source) && bus.status !== "delayed") {
      const key = `${bus.id}-cascade-risk`;
      if (!activeAlertKeys.has(key)) {
        activeAlertKeys.add(key);
        alerts.push(makeAlert({
          busId: bus.id, routeKey: bus.routeKey, severity: "warning",
          type: "cascade-risk",
          message: `${bus.busNumber} (${bus.source}→${bus.destination}) may face connecting passenger overflow — delayed bus arriving late at ${bus.source}`,
        }));
      }
    }
  });

  return alerts;
}

// ── Rule-based optimizer (thresholds documented) ─────────────────────────────
// Threshold: avgOccupancy > 0.88 AND demandMultiplier > 1.3 → add frequency
// Threshold: 2+ delayed buses AND avgSpeed < 35 → reroute
// Threshold: avgOccupancy > 0.75 AND any bus has < 3 seats → deploy reserve
// Threshold: avgOccupancy < 0.35 → redistribute load
// Threshold: avgSpeed > 80 AND 0 delayed → speed advisory (fuel optimisation)

export function generateOptimizations(buses: Bus[]): Record<string, RouteOptimization> {
  const byRoute: Record<string, Bus[]> = {};
  buses.forEach(b => { (byRoute[b.routeKey] ??= []).push(b); });

  const optimizations: Record<string, RouteOptimization> = {};

  Object.entries(byRoute).forEach(([routeKey, routeBuses]) => {
    const avgOccupancy = routeBuses.reduce((s, b) => s + (1 - b.availableSeats / b.totalSeats), 0) / routeBuses.length;
    const avgSpeed     = routeBuses.reduce((s, b) => s + b.speed, 0) / routeBuses.length;
    const delayedCount = routeBuses.filter(b => b.status === "delayed").length;
    const avgDemand    = routeBuses.reduce((s, b) => s + b.demandMultiplier, 0) / routeBuses.length;

    let action: OptimizationAction;
    let reason: string;
    let estimatedImpact: string;
    let confidence: number;
    let priority: RouteOptimization["priority"];

    if (avgOccupancy > 0.88 && avgDemand > 1.3) {
      action = "add-frequency"; reason = "High demand surge detected — occupancy >88%, demand multiplier >1.3×";
      estimatedImpact = "↓ 18% avg wait time, ↓ 22% overcrowding events";
      confidence = 87; priority = "urgent";
    } else if (delayedCount >= 2 && avgSpeed < 35) {
      action = "reroute"; reason = "2+ buses delayed with avg speed <35 km/h — likely traffic blockage";
      estimatedImpact = "↓ 12 min avg delay, ↓ cascade risk by ~60%";
      confidence = 74; priority = "high";
    } else if (avgOccupancy > 0.75 && routeBuses.some(b => b.availableSeats < 3)) {
      action = "deploy-reserve"; reason = "Near-full buses detected — reserve capacity needed within 15 min";
      estimatedImpact = "Absorb +120 passengers, ↑ 15% revenue capture";
      confidence = 91; priority = "high";
    } else if (avgOccupancy < 0.35) {
      action = "redistribute-load"; reason = "Utilisation <35% — excess capacity vs demand on this corridor";
      estimatedImpact = "↑ 28% utilisation, ↓ 14% fuel cost per passenger";
      confidence = 68; priority = "medium";
    } else if (avgSpeed > 80 && delayedCount === 0) {
      action = "speed-advisory"; reason = "All buses on time — opportunity to optimise for fuel economy";
      estimatedImpact = "↓ 8% fuel usage, ↓ 11% CO₂ per km";
      confidence = 82; priority = "low";
    } else {
      action = "redistribute-load"; reason = "Minor rebalancing opportunity";
      estimatedImpact = "↑ 5% overall corridor efficiency";
      confidence = 55; priority = "low";
    }

    optimizations[routeKey] = { action, reason, estimatedImpact, confidence, priority };
  });

  return optimizations;
}

export interface NetworkHealth {
  score: number;
  onTimePct: number;
  avgUtilization: number;
  criticalAlerts: number;
  activeRoutes: number;
  systemStatus: "nominal" | "degraded" | "critical";
  zoneHealth: Record<string, number>;
  co2SavedKg: number;    // vs all-car baseline (IPCC factors)
  fuelSavedL: number;
}

export function computeNetworkHealth(buses: Bus[], alerts: SystemAlert[]): NetworkHealth {
  const total    = buses.length;
  const onTime   = buses.filter(b => b.status === "on-time").length;
  const criticals = alerts.filter(a => a.severity === "critical" && !a.acknowledged).length;
  const utilSum  = buses.reduce((s, b) => s + (1 - b.availableSeats / b.totalSeats), 0);

  const onTimePct      = Math.round((onTime / total) * 100);
  const avgUtilization = Math.round((utilSum / total) * 100);
  const penaltyScore   = Math.min(40, criticals * 8);
  const score          = Math.max(0, Math.min(100, Math.round(onTimePct * 0.4 + avgUtilization * 0.3 + 30) - penaltyScore));

  const zoneMap: Record<string, Bus[]> = {};
  buses.forEach(b => {
    const zone = ROUTES[b.routeKey]?.zone ?? "Other";
    (zoneMap[zone] ??= []).push(b);
  });
  const zoneHealth: Record<string, number> = {};
  Object.entries(zoneMap).forEach(([zone, zb]) => {
    zoneHealth[zone] = Math.round((zb.filter(b => b.status === "on-time").length / zb.length) * 100);
  });

  // Environmental impact (IPCC factors: car=120g/km, bus=14g/km per passenger)
  const totalPassKm = buses.reduce((sum, bus) => {
    const occupancy = bus.totalSeats - bus.availableSeats;
    const completionRatio = Math.max(0, 1 - bus.etaMinutes / (bus.scheduledEta || 60));
    return sum + occupancy * bus.distanceKm * completionRatio;
  }, 0);
  const co2SavedKg = Math.round(((120 - 14) * totalPassKm) / 1000);
  const fuelSavedL = Math.round((8 / 100) * totalPassKm);

  return {
    score, onTimePct, avgUtilization, criticalAlerts: criticals,
    activeRoutes: Object.keys(zoneMap).length,
    systemStatus: criticals > 5 ? "critical" : score < 60 ? "degraded" : "nominal",
    zoneHealth, co2SavedKg, fuelSavedL,
  };
}
