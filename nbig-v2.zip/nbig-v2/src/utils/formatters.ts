/**
 * formatters.ts — Utility Formatters
 * Pure functions for display formatting. No side effects.
 */

import type { BusStatus } from "@/data/buses";

// ─────────────────────────────────────────────────────────────
// Time
// ─────────────────────────────────────────────────────────────

/** Converts a total seconds count to MM:SS display string */
export function fmtCountdown(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

// ─────────────────────────────────────────────────────────────
// Status
// ─────────────────────────────────────────────────────────────

export const STATUS_LABEL: Record<BusStatus, string> = {
  "on-time":      "On Time",
  "delayed":      "Delayed",
  "filling-fast": "Filling Fast",
  "critical":     "Critical",
  "diverted":     "Diverted",
};

/** Tailwind-compatible style tokens for each status */
export const STATUS_STYLES: Record<BusStatus, { bg: string; text: string; border: string }> = {
  "on-time":      { bg: "bg-success/10",     text: "text-success",     border: "border-success/30"     },
  "delayed":      { bg: "bg-destructive/10", text: "text-destructive", border: "border-destructive/30" },
  "filling-fast": { bg: "bg-warning/10",     text: "text-warning",     border: "border-warning/30"     },
  "critical":     { bg: "bg-destructive/10", text: "text-destructive", border: "border-destructive/30" },
  "diverted":     { bg: "bg-warning/10",     text: "text-warning",     border: "border-warning/30"     },
};

// ─────────────────────────────────────────────────────────────
// Numbers
// ─────────────────────────────────────────────────────────────

/** Returns a padded booking ID from a timestamp */
export function generateBookingId(): string {
  return `BK-${Date.now().toString(36).toUpperCase()}`;
}

/** Clamps a value between min and max */
export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}
