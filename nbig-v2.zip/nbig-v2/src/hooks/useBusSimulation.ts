/**
 * useBusSimulation.ts — NBIG v2 Master Simulation Hook
 * 
 * Splits concerns:
 *  - useFleetTick: pure state mutation every 5s
 *  - useBusSimulation: exposes fleet + analytics + replay buffer
 *
 * NEW: 60-tick replay buffer (last 5 minutes). Export to CSV.
 */
import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { Bus, MOCK_BUSES, SystemAlert, interpolatePosition, getDemandMultiplier } from "@/data/buses";
import { predictSeatFill } from "@/services/aiPrediction";
import { calculateEta } from "@/services/etaService";
import { detectStatus } from "@/services/delayDetection";
import { simulateDeviation } from "@/services/routeDeviation";
import {
  generateAlerts, generateOptimizations,
  computeNetworkHealth, NetworkHealth,
  detectCascadeRisks, resetAlertKeys,
} from "@/services/intelligenceEngine";

const TICK_MS        = 5000;
const SEAT_HISTORY_MAX = 8;
const MAX_ALERTS     = 60;
const REPLAY_MAX     = 60;   // ticks = 5 minutes of history

export interface FleetStats {
  total: number;
  delayed: number;
  onTime: number;
  filling: number;
  deviated: number;
  critical: number;
  utilPct: number;
  avgSpeed: number;
  onTimePct: number;
  networkHealth: NetworkHealth;
  overcrowdingCount: number;
  totalPassengers: number;
}

export function useBusSimulation() {
  const [buses, setBuses]   = useState<Bus[]>(MOCK_BUSES);
  const [alerts, setAlerts] = useState<SystemAlert[]>([]);
  const [replayHistory, setReplayHistory] = useState<Bus[][]>([]);
  const [replayIndex, setReplayIndex]     = useState<number | null>(null); // null = live
  const tickCount = useRef(0);

  // Demand multiplier updates every 5 minutes aligned to real time-of-day
  const demandTick = useRef(0);

  useEffect(() => {
    const interval = setInterval(() => {
      tickCount.current++;
      demandTick.current++;

      setBuses(prev => {
        const optimizations = generateOptimizations(prev);

        const next = prev.map(bus => {
          // Seats: passengers board/alight each tick
          const seatDelta  = Math.random() > 0.65 ? -1 : Math.random() > 0.85 ? 1 : 0;
          const newSeats   = Math.max(0, Math.min(bus.totalSeats, bus.availableSeats + seatDelta));
          const newHistory = [...bus.seatHistory.slice(-(SEAT_HISTORY_MAX - 1)), newSeats];

          // Speed with noise
          const speedNoise = (Math.random() - 0.48) * 5;
          const newSpeed   = Math.max(10, Math.min(95, bus.speed + speedNoise));

          // Deviation
          const { deviationKm, isDeviated } = simulateDeviation(bus.deviationKm);

          // Fuel decreases proportionally to speed (more realistic)
          const fuelBurn = (newSpeed / 1000) * 0.4;
          const newFuel  = Math.max(5, bus.fuelLevelPct - fuelBurn);

          // Demand drift — refreshes from real time-of-day every 60 ticks (~5 min)
          const newDemand = demandTick.current % 60 === 0
            ? getDemandMultiplier()
            : parseFloat((Math.max(0.7, Math.min(2.5, bus.demandMultiplier + (Math.random() - 0.48) * 0.04))).toFixed(2));

          // Progress advances along route
          const speedKmPerTick = (newSpeed / 3600) * (TICK_MS / 1000);
          const progressDelta  = (speedKmPerTick / bus.distanceKm) * 100;
          const newProgress    = Math.min(99, bus.progressPct + progressDelta);
          const newPos         = interpolatePosition(bus.route, newProgress);

          // Overcrowding risk
          const newOccupancy = 1 - newSeats / bus.totalSeats;
          const overcrowdingRisk = Math.min(100, Math.round(
            newOccupancy * 70 + (newDemand > 1.5 ? 20 : 0) + (newSeats < 3 ? 15 : 0)
          ));

          const rawEtaDelta = Math.random() > 0.3 ? -1 : Math.random() > 0.5 ? 1 : 0;
          const partialBus: Bus = {
            ...bus,
            availableSeats:  newSeats,
            seatHistory:     newHistory,
            speed:           Math.round(newSpeed),
            deviationKm,
            isDeviated,
            fuelLevelPct:    parseFloat(newFuel.toFixed(1)),
            demandMultiplier: newDemand,
            overcrowdingRisk,
            optimization:    optimizations[bus.routeKey],
            currentLat:      newPos.lat,
            currentLng:      newPos.lng,
            progressPct:     newProgress,
          };

          const newEta    = calculateEta(partialBus, rawEtaDelta);
          const newStatus = detectStatus({ ...partialBus, etaMinutes: newEta });

          return { ...partialBus, etaMinutes: newEta, status: newStatus };
        });

        // Push to replay buffer every tick
        setReplayHistory(h => [...h.slice(-REPLAY_MAX + 1), next]);

        // Generate alerts every 3 ticks with deduplication
        if (tickCount.current % 3 === 0) {
          resetAlertKeys();
          const newAlerts = [
            ...generateAlerts(next).slice(0, 6),
            ...detectCascadeRisks(next).slice(0, 3),
          ];
          if (newAlerts.length > 0) {
            setAlerts(prev => [...newAlerts, ...prev].slice(0, MAX_ALERTS));
          }
        }

        return next;
      });
    }, TICK_MS);

    return () => clearInterval(interval);
  }, []);

  const searchBuses = useCallback((source: string, destination: string): Bus[] => {
    const src  = source.toLowerCase();
    const dest = destination.toLowerCase();
    return buses
      .filter(b => b.source.toLowerCase().includes(src) && b.destination.toLowerCase().includes(dest))
      .sort((a, b) => a.etaMinutes - b.etaMinutes);
  }, [buses]);

  const getBus = useCallback((id: string) => buses.find(b => b.id === id), [buses]);

  const acknowledgeAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, acknowledged: true } : a));
  }, []);

  // Replay controls
  const setReplay = useCallback((index: number | null) => setReplayIndex(index), []);
  const displayBuses = replayIndex !== null
    ? (replayHistory[replayIndex] ?? buses)
    : buses;

  // Export fleet state to CSV
  const exportCsv = useCallback(() => {
    const cols = ["id","busNumber","routeKey","source","destination","status","availableSeats","totalSeats","etaMinutes","speed","overcrowdingRisk","fuelLevelPct","demandMultiplier","isDeviated","deviationKm","driver","fare"];
    const rows = buses.map(b => cols.map(c => (b as Record<string,unknown>)[c] ?? "").join(","));
    const csv  = [cols.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = `nbig-fleet-${new Date().toISOString().slice(0,19).replace(/:/g,"-")}.csv`;
    a.click(); URL.revokeObjectURL(url);
  }, [buses]);

  const stats = useMemo<FleetStats>(() => {
    const total    = displayBuses.length;
    const delayed  = displayBuses.filter(b => b.status === "delayed").length;
    const onTime   = displayBuses.filter(b => b.status === "on-time").length;
    const filling  = displayBuses.filter(b => b.status === "filling-fast").length;
    const deviated = displayBuses.filter(b => b.isDeviated).length;
    const critical = displayBuses.filter(b => b.overcrowdingRisk > 90).length;
    const overcrowdingCount = displayBuses.filter(b => b.overcrowdingRisk > 75).length;
    const totalPassengers = displayBuses.reduce((s, b) => s + (b.totalSeats - b.availableSeats), 0);
    const utilPct  = Math.round(displayBuses.reduce((s, b) => s + (1 - b.availableSeats / b.totalSeats), 0) / total * 100);
    const avgSpeed = Math.round(displayBuses.reduce((s, b) => s + b.speed, 0) / total);
    const onTimePct = Math.round((onTime / total) * 100);
    const networkHealth = computeNetworkHealth(displayBuses, alerts);
    return { total, delayed, onTime, filling, deviated, critical, utilPct, avgSpeed, onTimePct, networkHealth, overcrowdingCount, totalPassengers };
  }, [displayBuses, alerts]);

  return {
    buses: displayBuses,
    liveBuses: buses,
    stats,
    alerts,
    searchBuses,
    getBus,
    acknowledgeAlert,
    replayHistory,
    replayIndex,
    setReplay,
    exportCsv,
    isReplaying: replayIndex !== null,
  };
}
