# National Bus Intelligence Grid — v2.0

A data-driven prototype for real-time fleet management, delay prediction, and route optimisation across India's intercity bus network.

## What's new in v2.0

| Area | Change |
|---|---|
| Architecture | Merged `CommandCenter` + `Dashboard` into one tabbed `Dashboard` |
| Intelligence | Added **cascade risk detection** — downstream buses flagged when delayed hub bus arrives late |
| Simulation | GPS positions interpolated along real lat/lng coordinates — buses actually move |
| Demand | Time-of-day demand model — peaks at 7–9 AM and 5–7 PM, low overnight |
| Replay | 60-tick **replay buffer** (last 5 min) — digital twin lite with scrub slider |
| Alerts | **Deduplication** — same condition no longer spams the alert feed |
| Passenger UX | **Push notification toast** on delay status change with updated ETA |
| Export | **CSV export** of full fleet snapshot from authority dashboard |
| Honesty | Removed fake ticker stats, labelled optimizer as rule-based (not ML), cleaned roadmap |
| Deps | Removed ~15 unused Radix UI packages from package.json |
| Fuel | Fuel now decreases proportionally to speed (not random) |

## Architecture — 5 clean modules

```
Data Layer
  GPS coordinates · GTFS routes · time-of-day demand
        │
        ├── Module 1: Bus Simulation (useBusSimulation)
        │     5s tick · GPS interpolation · fuel decay · speed noise
        │
        ├── Module 2: Intelligence Engine (intelligenceEngine.ts)
        │     Delay detection · cascade risk · dedup alerts · network health
        │
        └── Module 3: Route Optimizer (intelligenceEngine.ts)
              Rule-based thresholds (documented) · frequency/reroute/reserve
                    │
          ┌─────────┴─────────┐
          │                   │
   Module 4:            Module 5:
   Passenger View        Authority Dashboard
   Search · Track        KPIs · Alerts · Optimizer
   ETA · Booking         Replay · CSV Export
   Push Alerts
```

## Key services

| File | Purpose |
|---|---|
| `data/buses.ts` | Types, city coordinates, route definitions, demand model |
| `services/aiPrediction.ts` | Seat fill rate extrapolation (rolling window) |
| `services/etaService.ts` | Speed-based ETA with EMA smoothing |
| `services/delayDetection.ts` | Dual-signal delay: speed threshold + schedule slip |
| `services/routeDeviation.ts` | GPS corridor drift simulation |
| `services/intelligenceEngine.ts` | Rule-based optimizer · cascade detection · network health |
| `hooks/useBusSimulation.ts` | Master hook: tick loop + replay buffer + CSV export |

## Getting started

```bash
npm install
npm run dev
```

## Tech stack

- React 18 + TypeScript
- Vite
- Tailwind CSS + shadcn/ui (trimmed to used components only)
- Recharts
- React Router v6
- TanStack Query

## Optimization thresholds (rule-based engine)

| Condition | Action |
|---|---|
| avgOccupancy > 88% AND demandMultiplier > 1.3× | Add frequency |
| 2+ delayed buses AND avgSpeed < 35 km/h | Reroute |
| avgOccupancy > 75% AND any bus has < 3 seats | Deploy reserve |
| avgOccupancy < 35% | Redistribute load |
| avgSpeed > 80 AND 0 delayed | Speed advisory (fuel economy) |

## What this is NOT

- Not a real GPS system (simulation only)
- Not an ML model — seat prediction is rate extrapolation
- Not connected to any live data feed
- Not GTFS-RT compliant yet (Phase 02 roadmap item)
